#!/usr/bin/env bash
java -cp .:\* clientSide.masterThief.MasterThiefClient $1 $2
