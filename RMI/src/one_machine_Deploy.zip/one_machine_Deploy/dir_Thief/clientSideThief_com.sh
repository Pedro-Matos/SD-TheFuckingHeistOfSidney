#!/usr/bin/env bash
java -cp .:\* clientSide.thief.ThiefClient $1 $2