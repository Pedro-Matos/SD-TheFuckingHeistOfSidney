/**
 * Package with the ConcentrationSite.
 * Uses the FIFO.
 */
package ConcorrentVersion.Regioes.base;