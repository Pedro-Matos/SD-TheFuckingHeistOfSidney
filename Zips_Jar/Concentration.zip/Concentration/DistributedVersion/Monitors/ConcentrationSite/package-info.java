/**
 * Package with the CollectionSite.
 * Uses the FIFO.
 */
package DistributedVersion.Monitors.ConcentrationSite;