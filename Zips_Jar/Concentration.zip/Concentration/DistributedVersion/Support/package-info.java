/**
 * Contains the structure associated to the FIFO.
 * It's used in the thief's ordenation at the CollectionSite.
 */
package DistributedVersion.Support;