/**
 * Package that contains the Actors
 * - Normal Thief
 * - Master Thief
 */
package DistributedVersion.Actors;