/**
 * Assault Partys and the management
 */
package DistributedVersion.Monitors.AssaultParty;