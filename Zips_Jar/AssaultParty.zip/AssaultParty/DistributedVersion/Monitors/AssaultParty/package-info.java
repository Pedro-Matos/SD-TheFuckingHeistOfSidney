/**
 * Assault Partys and the management
 */
package ConcorrentVersion.Regioes.gruposAssalto;