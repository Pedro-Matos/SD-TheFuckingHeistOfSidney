/**
 * ClientCom, ServerCom and ComPorts with all the ports and machines names
 */
package DistributedVersion.ComInfo;