package DistributedVersion.ComInfo;

/**
 * Created by tiagoalexbastos on 24-04-2017.
 */
public class ComPorts {

    public static final int portGeneralRepo = 22460;


    public static final int portMuseum = 22461;


    public static final int portConcentrationSite = 22462;


    public static final int portAssaultGroup = 22463;


    public static final int portCollectionSite = 22464;

    public static final String machine_log = "l040101-ws01";

    public static final String machine_museum = "l040101-ws02";

    public static final String machine_concentration = "l040101-ws03";

    public static final String machine_party = "l040101-ws04";

    public static final String machine_collection = "l040101-ws05";

    public static final String machine_thief = "l040101-ws06";

    public static final String machine_master = "l040101-ws08";

}
