/**
 * Package with all the constants used in this problem.
 * Also contains the General Repository that will create the log file.
 *
 */
package DistributedVersion.ProblemInformation;