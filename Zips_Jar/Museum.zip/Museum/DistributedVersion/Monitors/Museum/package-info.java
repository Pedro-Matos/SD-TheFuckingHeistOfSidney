/**
 * Package with the Museum
 * Creates all the rooms with their distances and number of paintings
 */
package ConcorrentVersion.Regioes.museu;